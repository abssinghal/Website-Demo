const excelData = [
    
    
    { "Brand": "Samsung", "Model Name": "Galaxy S21", "Glass Number": "G10", "Factory Size Number": "SM-G991B" },
    { "Brand": "Samsung", "Model Name": "Galaxy S20", "Glass Number": "G01", "Factory Size Number": "SM-G981B" },
    { "Brand": "Apple", "Model Name": "iPhone 14", "Glass Number": "G14", "Factory Size Number": "A2649" },
    { "Brand": "Apple", "Model Name": "iPhone 13", "Glass Number": "G15", "Factory Size Number": "A2633" },
    { "Brand": "Apple", "Model Name": "iPhone 12", "Glass Number": "G16", "Factory Size Number": "A2403" }
];

document.addEventListener("DOMContentLoaded", function () {
    const brandList = document.getElementById("brandList");
    const modelList = document.getElementById("modelList");
    const glassNumberCard = document.getElementById("glassNumberCard");
    const factorySizeNumberCard = document.getElementById("factorySizeNumberCard");

    const brands = [...new Set(excelData.map(item => item.Brand))];

    // Populate the brands list
    brands.forEach(brand => {
        let li = document.createElement("li");
        li.textContent = brand;
        li.addEventListener('click', function () {
            populateModels(brand);
            highlightSelection(brandList, li);
        });
        brandList.appendChild(li);
    });

    function populateModels(selectedBrand) {
        modelList.innerHTML = ""; // Clear existing models

        const models = excelData
            .filter(item => item.Brand === selectedBrand)
            .map(item => item["Model Name"]);

        models.forEach(model => {
            let li = document.createElement("li");
            li.textContent = model;
            li.addEventListener('click', function () {
                displayResult(model);
                highlightSelection(modelList, li);
            });
            modelList.appendChild(li);
        });

        // Clear result when brand changes
        glassNumberCard.textContent = 'Glass Number: ';
        factorySizeNumberCard.textContent = 'Factory Size Number: ';
    }

    function displayResult(selectedModel) {
        const result = excelData.find(item => item["Model Name"] === selectedModel);
        if (result) {
            glassNumberCard.textContent = `Glass Number: ${result["Glass Number"]}`;
            factorySizeNumberCard.textContent = `Factory Size Number: ${result["Factory Size Number"]}`;
        } else {
            glassNumberCard.textContent = 'Glass Number: ';
            factorySizeNumberCard.textContent = 'Factory Size Number: ';
        }
    }

    function highlightSelection(list, selectedItem) {
        const items = list.getElementsByTagName('li');
        for (let item of items) {
            item.classList.remove('selected');
        }
        selectedItem.classList.add('selected');
    }

    document.getElementById('backButton').addEventListener('click', function() {
        window.location.href = 'index.html';
    });
});
