// Assume that Excel data is loaded as JSON into this structure
const excelData = [
    { "Brand": "Select the Model Name", "Model Name": "", "Glass Number": "", "Factory Size Number": "" },
    { "Brand": "Samsung", "Model Name": "", "Glass Number": "", "Factory Size Number": "" },
    { "Brand": "Samsung", "Model Name": "Galaxy S21", "Glass Number": "G10", "Factory Size Number": "SM-G991B" },
    { "Brand": "Samsung", "Model Name": "Galaxy S20", "Glass Number": "G01", "Factory Size Number": "SM-G981B" },
    { "Brand": "Apple", "Model Name": "", "Glass Number": "", "Factory Size Number": "" },
    { "Brand": "Apple", "Model Name": "iPhone 14", "Glass Number": "G14", "Factory Size Number": "A2649" },
    { "Brand": "Apple", "Model Name": "iPhone 13", "Glass Number": "G15", "Factory Size Number": "A2633" },
    { "Brand": "Apple", "Model Name": "iPhone 12", "Glass Number": "G16", "Factory Size Number": "A2403" }
];

document.addEventListener("DOMContentLoaded", function () {
    const brandSelect = document.getElementById("brand");
    const modelSelect = document.getElementById("model");
    const resultDiv = document.getElementById("result");

    const brands = [...new Set(excelData.map(item => item.Brand))];

    // Populate the brands dropdown
    brands.forEach(brand => {
        let option = document.createElement("option");
        option.value = brand;
        option.textContent = brand;
        brandSelect.appendChild(option);
    });

    brandSelect.onchange = function () {
        const selectedBrand = brandSelect.value;
        modelSelect.innerHTML = ""; // Clear existing models

        const models = excelData
            .filter(item => item.Brand === selectedBrand)
            .map(item => item["Model Name"]);

        models.forEach(model => {
            let option = document.createElement("option");
            option.value = model;
            option.textContent = model;
            modelSelect.appendChild(option);
        });

        // Clear result when brand changes
        resultDiv.innerHTML = '';
    };

    modelSelect.onchange = function () {
        const selectedModel = modelSelect.value;
        const result = excelData.find(item => item["Model Name"] === selectedModel);
        if (result) {
            resultDiv.innerHTML = `Glass Number: ${result["Glass Number"]}<br>Factory Size Number: ${result["Factory Size Number"]}`;
        } else {
            resultDiv.textContent = 'No data found for the selected brand and model.';
        }
    };

    document.getElementById('backButton').addEventListener('click', function() {
        window.location.href = 'index.html';
    });
});
